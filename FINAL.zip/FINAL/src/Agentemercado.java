
public class Agentemercado {

	private long id;
	private String nombre;
	private plantaGeneracion[]plantasGeneracion;
	private String ciudad;
	private String presidente;
	private double dineroDisponible;
	
	public Agentemercado(long id, String nombre, plantaGeneracion[] plantasGeneracion, String ciudad, String presidente,
			double dineroDisponible) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.plantasGeneracion = plantasGeneracion;
		this.ciudad = ciudad;
		this.presidente = presidente;
		this.dineroDisponible = dineroDisponible;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public plantaGeneracion[] getPlantasGeneracion() {
		return plantasGeneracion;
	}

	public void setPlantasGeneracion(plantaGeneracion[] plantasGeneracion) {
		this.plantasGeneracion = plantasGeneracion;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getPresidente() {
		return presidente;
	}

	public void setPresidente(String presidente) {
		this.presidente = presidente;
	}

	public double getDineroDisponible() {
		return dineroDisponible;
	}

	public void setDineroDisponible(double dineroDisponible) {
		this.dineroDisponible = dineroDisponible;
	}
	public void mostrarplantas() {
		for (int i=0;i<plantasGeneracion.length;i++) {
			System.out.println(plantasGeneracion[i]);
	}
	}
	
	 public String mostrardatos () {
		 return "El agente se llama " + nombre + ", su ID es " + id + " y actualmente vive en " +ciudad+ ". El presidente de su planta es el señor " 
				 +presidente+ " y el dinero que tiene disponible es " +dineroDisponible+ " dólares";
	
	 }
	 public void comprarNuevaPlanta(plantaGeneracion a) {
		plantasGeneracion[0]=a;	
		}
}