import java.util.Scanner;



public class main {

public static void main(String[] args) {
Scanner scan = new Scanner(System.in);

int numeroplantas = 1;
int agente =1;



plantaGeneracion[] plantas = new plantaGeneracion[numeroplantas];
	for(int i=0;i<numeroplantas;i++) {
		System.out.println("Ingrese el ID de la planta");
		int id = scan.nextInt();
		System.out.println("Ingrese el recurso de la planta");
		String recurso = scan.next();
		System.out.println("Ingrese la ciudad donde  esta la planta");
		String ciudad = scan.next();
		System.out.println("Ingrese la fecha de creación de la planta");
		String fechainicial = scan.next();
		System.out.println("Ingrese el factor de disponibilidad ");
		double factordisponibilidad = scan.nextDouble();
		System.out.println("Ingrese el presupuesto de mantenimiento ");
		double dineroDisponible = scan.nextDouble();
		String fechas [] ={
				"9/9/2023",
				"8/7/2022"
		};
		
		plantas[i]=new plantaGeneracion(id,recurso,ciudad,fechainicial, fechas, factordisponibilidad, dineroDisponible);
		System.out.println("Información acerca de esta planta: " + plantas[i].planta());
}
	
	
	Agentemercado[] agentes = new Agentemercado[agente];
	for(int i=0; i<agente;i++) {
		System.out.println("Ingrese el nombre del agente");
		String nombre = scan.next();
		System.out.println("Ingrese el id del agente");
		int id = scan.nextInt();
		System.out.println("Ingrese la ciudad de residencia del agente");
		String ciudad = scan.next();
		System.out.println("Ingrese el nombre del presidente");
		String presidente = scan.next();
		System.out.println("Ingrese el dinero disponible");
		double dineroDisponible = scan.nextDouble();
		
		agentes[i]=new Agentemercado(id,nombre,plantas,ciudad,presidente,dineroDisponible);
		System.out.println("Información acerca del agente: " + agentes[i].mostrardatos());
		agentes[i].mostrarplantas();
	}
	

}
}