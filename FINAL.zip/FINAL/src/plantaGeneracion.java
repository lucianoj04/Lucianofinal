import java.util.Arrays;

public class plantaGeneracion {

	private int id;
	private String recurso;
	private String ciudad;
	private String fechainicial;
	private String [] fechasmantenimiento;
	private double factordisponibilidad;
	private double presupuestoMantenimiento;
	
	
	public void realizarMantenimiento(double a) {
		presupuestoMantenimiento=-a;
	}
	
	
	public plantaGeneracion(int id, String recurso, String ciudad, String fechainicial, String[] fechasmantenimiento,
			double factordisponibilidad, double presupuestoMantenimiento) {
		super();
		this.id = id;
		this.recurso = recurso;
		this.ciudad = ciudad;
		this.fechainicial = fechainicial;
		this.fechasmantenimiento = fechasmantenimiento;
		this.factordisponibilidad = factordisponibilidad;
		this.presupuestoMantenimiento = presupuestoMantenimiento;
	}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getRecurso() {
	return recurso;
}

public void setRecurso(String recurso) {
	this.recurso = recurso;
}

public String getCiudad() {
	return ciudad;
}

public void setCiudad(String ciudad) {
	this.ciudad = ciudad;
}

public String getFechainicial() {
	return fechainicial;
}

public void setFechainicial(String fechainicial) {
	this.fechainicial = fechainicial;
}

public String[] getFechasmantenimiento() {
	return fechasmantenimiento;
}

public void setFechasmantenimiento(String[] fechasmantenimiento) {
	this.fechasmantenimiento = fechasmantenimiento;
}

public double getFactordisponibilidad() {
	return factordisponibilidad;
}

public void setFactordisponibilidad(double factordisponibilidad) {
	this.factordisponibilidad = factordisponibilidad;
}

public double getPresupuestoMantenimiento() {
	return presupuestoMantenimiento;
}

public void setPresupuestoMantenimiento(double presupuestoMantenimiento) {
	this.presupuestoMantenimiento = presupuestoMantenimiento;
}
	
	
public String planta () {
	return "El ID de la planta es " +id+ " y su recurso es " +recurso+ ". Esta ubicada en " +ciudad+ " y su fecha inicial fue el " +fechainicial+
			". Su factor de disponibilidad es " +factordisponibilidad+ " y su presupuesto de mantenimiento es " +presupuestoMantenimiento+ 
			". Las fechas de mantenimiento son: "+ fechasmantenimiento;
}


@Override
public String toString() {
	return "plantaGeneracion [id=" + id + ", recurso=" + recurso + ", ciudad=" + ciudad + ", fechainicial="
			+ fechainicial + ", fechasmantenimiento=" + Arrays.toString(fechasmantenimiento) + ", factordisponibilidad="
			+ factordisponibilidad + ", presupuestoMantenimiento=" + presupuestoMantenimiento + "]";
}
	

	
	
	
	
	
	
	
	
	
}
